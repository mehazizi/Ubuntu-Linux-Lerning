# فصل ۲۸ - Proxmox Backup Server | عیب‌یابی

## مشکل: پشتیبان‌گیری شکست می‌خورد
```bash
# در PVE:
journalctl -u pvedaemon | grep "backup"
# در PBS:
journalctl | grep "proxmox-backup" | tail -30
# فضای دیسک:
df -h /mnt/backup-disk
```

## مشکل: Verification شکست می‌خورد
```bash
# پشتیبان ممکن است خراب باشد
# اجرای مجدد با --debug:
proxmox-backup-client verify --debug
# اگر خراب است، پشتیبان جدید بگیرید
```

## مشکل: GC فضا آزاد نمی‌کند
```bash
# ابتدا Prune کنید، سپس GC:
proxmox-backup-manager prune ...
proxmox-backup-manager garbage-collection start DATASTORE
# GC زمان می‌برد، صبر کنید
```

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[lab|← آزمایشگاه]]