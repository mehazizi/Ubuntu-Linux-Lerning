# فصل ۲۹ - Mailcow | آزمایشگاه

## تمرین ۱: بررسی DNS قبل از نصب
```bash
# برای دامنه mail.example.com:
dig A mail.example.com
dig MX example.com
dig TXT example.com | grep spf

# بررسی PTR:
SERVER_IP=$(curl -s ifconfig.me)
dig -x $SERVER_IP
```

## تمرین ۲: نصب Mailcow
```bash
git clone https://github.com/mailcow/mailcow-dockerized /opt/mailcow
cd /opt/mailcow
./generate_config.sh
# وارد کردن: mail.example.com

# بررسی پیکربندی
cat mailcow.conf | head -20

docker-compose pull
docker-compose up -d
docker-compose ps
```

## تمرین ۳: پیکربندی اولیه
```
در رابط وب https://mail.example.com:
۱. ورود با admin / moohoo (رمز را تغییر دهید)
۲. Configuration → Mail Domains → Add domain
۳. Configuration → Mailboxes → Add mailbox
۴. کلید DKIM را کپی کنید
۵. در DNS سرور اضافه کنید
```

## تمرین ۴: آزمایش ارسال و دریافت
```bash
# تست با ابزار آنلاین:
# mail-tester.com
# mxtoolbox.com/emailhealth
```

### ✅ چک‌لیست یادگیری
- [ ] رکوردهای DNS لازم را پیکربندی کرده‌ام
- [ ] Mailcow را نصب کرده‌ام
- [ ] صندوق ایمیل ساخته‌ام
- [ ] DKIM را تنظیم کرده‌ام

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[troubleshooting|← عیب‌یابی]]