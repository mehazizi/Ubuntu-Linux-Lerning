# فصل ۲۸ - Proxmox Backup Server | دستورات

## نصب
```bash
# روی سرور جداگانه:
# دانلود ISO از proxmox.com/en/downloads/proxmox-backup-server
# نصب مانند Proxmox VE
```

## مدیریت Datastore
```bash
proxmox-backup-manager datastore list
proxmox-backup-manager datastore create mystore /mnt/backup
proxmox-backup-manager datastore remove mystore
```

## پشتیبان‌گیری از Proxmox VE
```bash
# در سرور PVE - افزودن PBS به storage:
# Datacenter → Storage → Add → Proxmox Backup Server

# پشتیبان از CLI:
vzdump VMID --storage pbs-storage --compress zstd --mode snapshot
```

## بررسی و Verification
```bash
# در PBS:
proxmox-backup-client list
proxmox-backup-client verify

# از رابط وب PBS:
# Datastore → Verify Jobs → Add
```

## Prune
```bash
proxmox-backup-manager prune-job list
# از رابط وب:
# Datastore → Prune & GC → Prune Jobs → Add
# تنظیم: keep-daily=7, keep-weekly=4, keep-monthly=6
```

## Garbage Collection
```bash
proxmox-backup-manager garbage-collection start DATASTORE
proxmox-backup-manager garbage-collection status DATASTORE
# از رابط وب:
# Datastore → Prune & GC → Start GC
```

## Sync
```bash
# همگام‌سازی با PBS دیگر:
# از رابط وب:
# Datastore → Sync Jobs → Add
# تنظیم Remote و Datastore مقصد
```

---
[[summary|← خلاصه]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]