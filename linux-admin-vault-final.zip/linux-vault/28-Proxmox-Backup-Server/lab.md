# فصل ۲۸ - Proxmox Backup Server | آزمایشگاه

## تمرین ۱: نصب PBS
```
۱. ISO را دانلود کنید
۲. روی سرور جداگانه نصب کنید
۳. به https://PBS_IP:8007 وصل شوید
```

## تمرین ۲: ساخت Datastore
```
۱. در رابط وب: Administration → Datastore → Add Datastore
۲. نام: main-backup
۳. مسیر: /mnt/backup-disk
۴. تأیید
```

## تمرین ۳: اتصال PBS به PVE
```
در رابط وب Proxmox VE:
۱. Datacenter → Storage → Add → Proxmox Backup Server
۲. آدرس PBS و اطلاعات ورود را وارد کنید
۳. Datastore را انتخاب کنید
```

## تمرین ۴: پشتیبان‌گیری و Restore
```bash
# در PVE از CLI:
vzdump 100 --storage pbs-main --mode snapshot --compress zstd

# بررسی در PBS:
proxmox-backup-client list
```

## تمرین ۵: تنظیم Prune Job
```
در رابط وب PBS:
Datastore → main-backup → Prune & GC → Prune Jobs → Add
keep-daily: 7
keep-weekly: 4
keep-monthly: 3
Schedule: daily
```

### ✅ چک‌لیست یادگیری
- [ ] PBS نصب و پیکربندی کرده‌ام
- [ ] Datastore ساخته‌ام
- [ ] PBS را به PVE وصل کرده‌ام
- [ ] Prune Job تنظیم کرده‌ام

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[troubleshooting|← عیب‌یابی]]