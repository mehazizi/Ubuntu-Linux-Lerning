# فصل ۲۶ - مجازی‌سازی با KVM | خلاصه

## KVM چیست؟
Kernel-based Virtual Machine - ماژول هسته لینوکس که آن را به یک hypervisor تبدیل می‌کند.

## معماری
```
VM1  VM2  VM3      ← Guest OS
 ↓    ↓    ↓
QEMU (Emulator)   ← شبیه‌سازی سخت‌افزار
     ↓
  KVM (Kernel)    ← دسترسی مستقیم به CPU
     ↓
  Hardware        ← CPU با پشتیبانی VT-x/AMD-V
```

## مقایسه ابزارها
| ابزار | کاربرد |
|-------|---------|
| **KVM** | ماژول هسته |
| **QEMU** | شبیه‌سازی سخت‌افزار |
| **libvirt** | API مدیریت مجازی‌سازی |
| **virsh** | خط فرمان libvirt |
| **virt-manager** | رابط گرافیکی |

## پیش‌نیاز: پشتیبانی CPU
```bash
egrep -c '(vmx|svm)' /proc/cpuinfo
# اگر > 0 باشد: پشتیبانی وجود دارد
```

---
[[commands|← دستورات]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]