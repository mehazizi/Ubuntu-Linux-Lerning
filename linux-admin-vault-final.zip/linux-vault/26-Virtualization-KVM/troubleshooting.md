# فصل ۲۶ - مجازی‌سازی با KVM | عیب‌یابی

## مشکل: KVM پشتیبانی نمی‌شود
```bash
egrep -c '(vmx|svm)' /proc/cpuinfo  # باید > 0 باشد
sudo kvm-ok
# اگر در VPS هستید، nested virtualization را فعال کنید
cat /sys/module/kvm_intel/parameters/nested
echo "options kvm_intel nested=1" | sudo tee /etc/modprobe.d/kvm.conf
```

## مشکل: VM شروع نمی‌شود
```bash
virsh domstate vm-name
sudo journalctl -u libvirtd
virsh start vm-name --console    # با نمایش خطا
```

## مشکل: شبکه VM کار نمی‌کند
```bash
virsh net-list --all
virsh net-start default
virsh net-autostart default
sudo systemctl restart libvirtd
```

## مشکل: فضای دیسک VM زیاد است
```bash
du -sh /var/lib/libvirt/images/*
# فشرده‌سازی qcow2:
sudo virt-sparsify --in-place /var/lib/libvirt/images/vm.qcow2
```

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[lab|← آزمایشگاه]]