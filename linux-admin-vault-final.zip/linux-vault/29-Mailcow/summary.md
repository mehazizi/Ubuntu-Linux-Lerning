# فصل ۲۹ - Mailcow | خلاصه

## Mailcow چیست؟
یک راه‌حل سرور ایمیل کامل مبتنی بر Docker که شامل:
- **Postfix**: ارسال ایمیل (MTA)
- **Dovecot**: دریافت ایمیل (IMAP/POP3)
- **SOGo**: رابط وب
- **rspamd**: فیلتر اسپم
- **Nginx**: وب‌سرور

## پیش‌نیازهای DNS
| رکورد | مقدار | کاربرد |
|-------|-------|---------|
| A | IP سرور | اشاره دامنه به سرور |
| MX | mail.domain.com | سرور دریافت ایمیل |
| SPF | TXT | جلوگیری از جعل |
| DKIM | TXT | امضای دیجیتال |
| DMARC | TXT | سیاست احراز هویت |
| PTR | domain | Reverse DNS |

## SPF (نمونه)
```
v=spf1 mx a ip4:SERVER_IP ~all
```

## DMARC (نمونه)
```
v=DMARC1; p=quarantine; rua=mailto:admin@domain.com
```

---
[[commands|← دستورات]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]