# فصل ۲۷ - Proxmox VE | دستورات

## دسترسی
```bash
# رابط وب: https://SERVER_IP:8006
# کاربر: root
# رمز: رمز سیستم

ssh root@proxmox-server         # دسترسی SSH
```

## مدیریت VM با CLI
```bash
qm list                         # لیست VMها
qm status VMID                  # وضعیت VM
qm start VMID                   # راه‌اندازی
qm shutdown VMID                # خاموش کردن
qm stop VMID                    # خاموش اجباری
qm reboot VMID                  # ریبوت
qm suspend VMID                 # تعلیق
qm resume VMID                  # ادامه
qm config VMID                  # پیکربندی VM
qm set VMID --memory 4096       # تغییر حافظه
qm set VMID --cores 4           # تغییر CPU
```

## Snapshot VM
```bash
qm snapshot VMID snap1 --description "قبل از تغییرات"
qm listsnapshot VMID
qm rollback VMID snap1
qm delsnapshot VMID snap1
```

## مدیریت LXC
```bash
pct list                        # لیست کانتینرها
pct status CTID
pct start CTID
pct shutdown CTID
pct enter CTID                  # ورود به کانتینر
pct exec CTID -- command        # اجرای دستور
pct config CTID                 # پیکربندی
```

## Storage
```bash
pvesm list local                # محتوای storage
pvesm status                    # وضعیت همه storageها
pvesm alloc local VMID disk.qcow2 20G  # تخصیص فضا
```

## Backup و Restore
```bash
vzdump VMID --storage local --compress gzip    # پشتیبان VM
vzdump VMID --mode snapshot                    # با snapshot
# از رابط وب: Datacenter → Backup
qmrestore /path/to/backup.vma VMID             # بازیابی VM
pct restore CTID /path/to/backup.tar.gz        # بازیابی CT
```

## Cluster
```bash
pvecm status                    # وضعیت cluster
pvecm nodes                     # لیست nodeها
pvecm create CLUSTER_NAME       # ساخت cluster
pvecm add MASTER_IP             # پیوستن به cluster
```

---
[[summary|← خلاصه]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]