# فصل ۲۷ - Proxmox VE | آزمایشگاه

## تمرین ۱: نصب Proxmox VE
```
۱. ISO را از proxmox.com دانلود کنید
۲. روی USB Bootable بسازید
۳. نصب را انجام دهید
۴. به https://IP:8006 وصل شوید
```

## تمرین ۲: ساخت VM
```
۱. در رابط وب روی Create VM کلیک کنید
۲. General: نام و VMID تنظیم کنید
۳. OS: ISO را انتخاب کنید
۴. System: پیش‌فرض بگذارید
۵. Disks: حجم را تنظیم کنید
۶. CPU و Memory را تنظیم کنید
۷. Network: پیش‌فرض (vmbr0)
۸. Finish
```

## تمرین ۳: عملیات با CLI
```bash
qm list
qm config 100
qm snapshot 100 before-update
qm listsnapshot 100
```

## تمرین ۴: پشتیبان‌گیری
```bash
vzdump 100 --storage local --compress gzip --mode snapshot
ls /var/lib/vz/dump/
```

### ✅ چک‌لیست یادگیری
- [ ] Proxmox را نصب کرده‌ام
- [ ] VM و CT ساخته‌ام
- [ ] Snapshot و Backup انجام داده‌ام
- [ ] با CLI مدیریت کرده‌ام

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[troubleshooting|← عیب‌یابی]]