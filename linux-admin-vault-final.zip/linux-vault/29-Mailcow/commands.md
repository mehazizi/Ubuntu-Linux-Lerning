# فصل ۲۹ - Mailcow | دستورات

## نصب
```bash
sudo apt install git curl
git clone https://github.com/mailcow/mailcow-dockerized
cd mailcow-dockerized
./generate_config.sh           # ساخت پیکربندی (MAILCOW_HOSTNAME را وارد کنید)
docker-compose pull
docker-compose up -d
```

## مدیریت سرویس‌ها
```bash
cd /opt/mailcow-dockerized     # پوشه نصب
docker-compose ps              # وضعیت همه سرویس‌ها
docker-compose logs -f         # لاگ زنده
docker-compose logs -f postfix-mailcow  # لاگ یک سرویس
docker-compose restart postfix-mailcow
docker-compose pull && docker-compose up -d  # به‌روزرسانی
```

## بررسی DNS
```bash
dig MX domain.com
dig TXT domain.com | grep spf
dig TXT _dmarc.domain.com
dig TXT dkim._domainkey.domain.com
# بررسی PTR:
dig -x SERVER_IP
```

## بررسی ایمیل
```bash
# تست ارسال:
echo "تست" | docker exec -i mailcowdockerized_postfix-mailcow_1   sendmail -v test@domain.com

# صف ایمیل:
docker exec mailcowdockerized_postfix-mailcow_1 postqueue -p
docker exec mailcowdockerized_postfix-mailcow_1 postqueue -f  # ارسال مجدد

# لاگ ایمیل:
docker exec mailcowdockerized_postfix-mailcow_1   tail -f /var/log/mail.log
```

## پشتیبان‌گیری
```bash
cd /opt/mailcow-dockerized
./helper-scripts/backup_and_restore.sh backup all
ls /opt/mailcow-dockerized/backups/
./helper-scripts/backup_and_restore.sh restore backup_TIMESTAMP
```

---
[[summary|← خلاصه]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]