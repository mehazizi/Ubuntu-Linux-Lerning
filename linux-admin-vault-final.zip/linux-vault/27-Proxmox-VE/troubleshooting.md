# فصل ۲۷ - Proxmox VE | عیب‌یابی

## مشکل: رابط وب در دسترس نیست
```bash
systemctl status pveproxy
systemctl restart pveproxy
ss -tulnp | grep 8006
journalctl -u pveproxy
```

## مشکل: VM شروع نمی‌شود
```bash
qm status VMID
cat /var/log/pve/qemu-server/VMID.log | tail -30
# بررسی فضای دیسک:
pvesm status
df -h
```

## مشکل: Cluster quorum از دست رفته
```bash
pvecm status
# در اضطرار (یک node):
systemctl stop corosync
pvecm expected 1
systemctl start pve-cluster
```

## مشکل: Storage در دسترس نیست
```bash
pvesm status
systemctl status nfs-client   # اگر NFS است
df -h
```

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[lab|← آزمایشگاه]]