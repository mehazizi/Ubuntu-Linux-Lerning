# فصل ۲۹ - Mailcow | عیب‌یابی

## مشکل: ایمیل‌ها به اسپم می‌روند
```bash
# بررسی امتیاز SPF، DKIM، DMARC:
# ارسال به check-auth@verifier.port25.com
# یا استفاده از mail-tester.com

# بررسی blacklist بودن IP:
# mxtoolbox.com/blacklists.aspx
```

## مشکل: ایمیل ارسال نمی‌شود
```bash
docker-compose logs postfix-mailcow | tail -50
docker exec mailcowdockerized_postfix-mailcow_1 postqueue -p
# بررسی پورت ۲۵:
telnet mail.receiver.com 25
```

## مشکل: ایمیل دریافت نمی‌شود
```bash
dig MX yourdomain.com          # آیا MX درست است؟
docker-compose logs dovecot-mailcow | tail -30
ss -tulnp | grep :993          # IMAPS باز است؟
```

## مشکل: رابط وب در دسترس نیست
```bash
docker-compose ps | grep nginx
docker-compose logs nginx-mailcow | tail -20
ss -tulnp | grep :443
```

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[lab|← آزمایشگاه]]