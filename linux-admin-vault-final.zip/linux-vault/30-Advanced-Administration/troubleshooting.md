# فصل ۳۰ - مدیریت پیشرفته | عیب‌یابی

## روش‌شناسی کلی
```
مشکل گزارش شده
        ↓
آیا تکرارپذیر است؟
        ↓
جمع‌آوری اطلاعات:
  - لاگ‌ها
  - متریک‌ها
  - تغییرات اخیر
        ↓
فرضیه‌سازی
        ↓
آزمایش (کم‌ریسک‌ترین ابتدا)
        ↓
راه‌حل و تأیید
        ↓
مستندسازی
```

## دستورات اضطراری
```bash
# بررسی کلی سریع
systemctl list-units --failed
df -h && free -h && uptime
journalctl -p err -b --no-pager | tail -30

# پیدا کردن مشکل شبکه
ip addr && ip route
ping -c 2 8.8.8.8
ss -tulnp

# پیدا کردن فرآیند مشکل‌دار
ps aux --sort=-%cpu | head -10
ps aux --sort=-%mem | head -10
lsof -i | grep ESTABLISHED | head -10
```

## منابع یادگیری بیشتر
- `man` pages - راهنمای رسمی هر دستور
- `tldr` - نمونه‌های کاربردی
- Linux Foundation Documentation
- Arch Wiki - مرجع عمومی لینوکس
- Stack Exchange - سوال و جواب

---
[[summary|← خلاصه]] | [[commands|← دستورات]] | [[lab|← آزمایشگاه]]