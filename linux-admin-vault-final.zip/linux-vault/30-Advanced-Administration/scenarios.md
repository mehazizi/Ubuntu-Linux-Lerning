# فصل ۳۰ - مدیریت پیشرفته | سناریوها

## سناریو ۱: سرور پاسخ نمی‌دهد
```bash
# از کنسول محلی یا KVM:
# ۱. آیا سیستم بوت شده؟
systemctl list-units --failed

# ۲. دیسک پر نشده؟
df -h

# ۳. حافظه کافی دارد؟
free -h

# ۴. Load Average چقدر است؟
uptime

# ۵. فرآیند مشکل‌دار کدام است؟
top

# ۶. شبکه مشکل دارد؟
ip addr show
ping gateway
```

## سناریو ۲: سایت آهسته است
```bash
# ۱. سرور خودش آهسته است یا شبکه؟
ping server
curl -w "@curl-format.txt" -o /dev/null -s http://localhost/

# ۲. وب‌سرور مشکل دارد؟
systemctl status nginx
journalctl -u nginx -n 50

# ۳. پایگاه داده مشکل دارد؟
systemctl status mysql
mysql -e "SHOW PROCESSLIST;"

# ۴. دیسک I/O گلوگاه است؟
iostat -x 1 5

# ۵. حافظه کافی است؟
free -h
```

## سناریو ۳: هک شده‌ام؟
```bash
# ۱. ورودهای مشکوک
grep "Accepted password" /var/log/auth.log | tail -20
last | head -20

# ۲. فرآیندهای مشکوک
ps aux | grep -v "^root\|^www-data\|^mysql"
lsof -i -P -n | grep ESTABLISHED

# ۳. فایل‌های تازه‌تغییریافته
find /tmp /var/tmp -mtime -1 -type f 2>/dev/null
find / -perm -4000 -newer /etc/passwd 2>/dev/null

# ۴. کاربران جدید
grep -E ":[0-9]{4}:" /etc/passwd   # UID > 999

# ۵. اقدام اضطراری:
# ایزوله کردن سرور از شبکه
sudo ufw deny incoming
sudo ufw deny outgoing
sudo ufw allow from YOUR_IP to any port 22
```

## سناریو ۴: دیسک پر شده
```bash
# ۱. کجا پر شده؟
df -h

# ۲. چه چیزی فضا گرفته؟
du -h /var 2>/dev/null | sort -rh | head -20

# ۳. پاک‌سازی فوری:
sudo journalctl --vacuum-size=500M
sudo apt clean
find /tmp -type f -atime +7 -delete
find /var/log -name "*.gz" -mtime +30 -delete

# ۴. لاگ‌های حجیم:
ls -lhS /var/log/ | head -10
sudo truncate -s 0 /var/log/large_log.log
```

## سناریو ۵: سرویس کرش می‌کند
```bash
# ۱. وضعیت و لاگ:
systemctl status service-name
journalctl -u service-name -n 100 --no-pager

# ۲. خطای OOM (Out of Memory)?
dmesg | grep -i "oom\|killed"

# ۳. راه‌اندازی خودکار بعد از کرش:
sudo nano /etc/systemd/system/service-name.service
# [Service]
# Restart=always
# RestartSec=5

sudo systemctl daemon-reload
sudo systemctl restart service-name
```
