# فصل ۲۸ - Proxmox Backup Server | خلاصه

## PBS چیست؟
Proxmox Backup Server - راه‌حل پشتیبان‌گیری اختصاصی برای VMها و CTهای Proxmox با قابلیت deduplication.

## مفاهیم
| مفهوم | توضیح |
|-------|-------|
| **Datastore** | مخزن ذخیره‌سازی پشتیبان‌ها |
| **Namespace** | گروه‌بندی پشتیبان‌ها |
| **Chunk** | واحد deduplication |
| **Verification** | تأیید صحت پشتیبان |
| **Prune** | حذف پشتیبان‌های قدیمی |
| **GC** | Garbage Collection |

## مزایای PBS نسبت به vzdump ساده
- Deduplication: فضای کمتر
- Incremental: فقط تغییرات
- Encryption: رمزنگاری
- Verification: تأیید صحت
- Sync: همگام‌سازی با PBS دیگر

## سیاست Prune (نگهداری)
```
keep-last: N      ← آخرین N پشتیبان
keep-hourly: N    ← N پشتیبان ساعتی
keep-daily: N     ← N پشتیبان روزانه
keep-weekly: N    ← N پشتیبان هفتگی
keep-monthly: N   ← N پشتیبان ماهانه
keep-yearly: N    ← N پشتیبان سالانه
```

---
[[commands|← دستورات]] | [[lab|← آزمایشگاه]] | [[troubleshooting|← عیب‌یابی]]