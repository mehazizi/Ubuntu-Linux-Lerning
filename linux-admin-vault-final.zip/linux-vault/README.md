# 🐧 Linux System Administration Master Course

## راهنمای استفاده
هر فصل یک پوشه دارد با ۴ فایل:
- 📋 `summary.md` ← مفاهیم و خلاصه
- 💻 `commands.md` ← دستورات آماده استفاده
- 🧪 `lab.md` ← تمرین‌های عملی
- 🔧 `troubleshooting.md` ← عیب‌یابی

---

## نقشه راه یادگیری

### 🟢 سطح پایه
| فصل | موضوع |
|-----|-------|
| [[01-Linux-Fundamentals/summary\|01]] | مبانی لینوکس |
| [[02-Navigation-Filesystem/summary\|02]] | ناوبری و فایل‌سیستم |
| [[03-Files-Directories/summary\|03]] | فایل‌ها و پوشه‌ها |
| [[04-Viewing-Editing-Files/summary\|04]] | مشاهده و ویرایش فایل |
| [[05-Text-Processing/summary\|05]] | پردازش متن |
| [[06-Package-Management/summary\|06]] | مدیریت بسته |
| [[07-Vim-Editor/summary\|07]] | ویرایشگر Vim |
| [[08-Users-Permissions/summary\|08]] | کاربران و مجوزها |

### 🟡 سطح میانی
| فصل | موضوع |
|-----|-------|
| [[09-Network-Configuration/summary\|09]] | پیکربندی شبکه |
| [[10-Process-Management/summary\|10]] | مدیریت فرآیندها |
| [[11-Systemd-Services/summary\|11]] | Systemd و سرویس‌ها |
| [[12-Storage/summary\|12]] | ذخیره‌سازی |
| [[13-LVM/summary\|13]] | LVM |
| [[14-RAID/summary\|14]] | RAID |
| [[15-Logs/summary\|15]] | لاگ‌ها |
| [[16-Scheduling/summary\|16]] | زمان‌بندی وظایف |
| [[17-Archive-Compression/summary\|17]] | آرشیو و فشرده‌سازی |
| [[18-SSH/summary\|18]] | SSH |
| [[19-Firewall/summary\|19]] | فایروال |
| [[20-Bash-Scripting/summary\|20]] | Bash Scripting |

### 🔴 سطح پیشرفته
| فصل | موضوع |
|-----|-------|
| [[21-Disk-Performance-Monitoring/summary\|21]] | پایش دیسک و عملکرد |
| [[22-Kernel-Management/summary\|22]] | مدیریت هسته |
| [[23-Boot-Loader/summary\|23]] | بوت‌لودر |
| [[24-Security/summary\|24]] | امنیت |
| [[25-Containers-Docker/summary\|25]] | Docker |
| [[26-Virtualization-KVM/summary\|26]] | مجازی‌سازی KVM |
| [[27-Proxmox-VE/summary\|27]] | Proxmox VE |
| [[28-Proxmox-Backup-Server/summary\|28]] | Proxmox Backup Server |
| [[29-Mailcow/summary\|29]] | Mailcow |
| [[30-Advanced-Administration/summary\|30]] | مدیریت پیشرفته |

---

## دستورات اضطراری

```bash
# بررسی کلی سریع
systemctl list-units --failed
df -h && free -h && uptime

# لاگ‌های خطا
journalctl -p err -b | tail -30

# فرآیند مشکل‌دار
ps aux --sort=-%cpu | head -5

# شبکه
ss -tulnp
```
